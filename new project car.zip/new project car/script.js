


function changeStyle() {
    var span = document.getElementById("hilux2018");
    if(span.style.display === "block") {
        span.style.display = "none";
    } else {
        span.style.display = "block";
    }
    }



function changeStyle1() {
    var span = document.getElementById("range-rover");
    if(span.style.display === "block") {
        span.style.display = "none";
    } else {
        span.style.display = "block";
    }
    }

    function changeStyle2() {
        var span = document.getElementById("hilux2020");
        if(span.style.display === "block") {
            span.style.display = "none";
        } else {
            span.style.display = "block";
        }
        }

        function changeStyle4() {
            var span = document.getElementById("bmw-jeep");
            if(span.style.display === "block") {
                span.style.display = "none";
            } else {
                span.style.display = "block";
            }
            }

            function changeStyle3() {
                var span = document.getElementById("lamborghini");
                if(span.style.display === "block") {
                    span.style.display = "none";
                } else {
                    span.style.display = "block";
                }
                }

                function changeStyle5() {
                    var span = document.getElementById("bmw-salon");
                    if(span.style.display === "block") {
                        span.style.display = "none";
                    } else {
                        span.style.display = "block";
                    }
                    }



                    function changeStyle7() {
                        var span = document.getElementById("click here for gnv-auto-no");
                        if(span.style.display === "block") {
                            span.style.display = "none";
                        } else {
                            span.style.display = "block";
                        }
                        }